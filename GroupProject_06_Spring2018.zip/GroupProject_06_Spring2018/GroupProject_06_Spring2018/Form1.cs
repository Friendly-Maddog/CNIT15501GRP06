﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject_06_Spring2018
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int mIndex = 0;
        private int cSize = 10;


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
