﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject_06_Spring2018
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private string[] QuestionsEasy = new string[questionMax]; //creates array for a list of easy questions

        private string[] QuestionsRegular = new string[questionMax]; //creates array for a list of regular questions

        private string[] QuestionsHard = new string[questionMax]; //creates array for a list of hard questions

        private const int questionMax = 10; //sets max question size for each difficulty

        private int mIndex = 0; //counter to keep track what question the user is on

        private int mHealth = 3; //live counter 


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }

        private void cboQDifficulty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
