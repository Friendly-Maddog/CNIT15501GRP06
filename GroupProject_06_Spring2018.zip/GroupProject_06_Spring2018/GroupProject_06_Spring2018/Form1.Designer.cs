﻿namespace GroupProject_06_Spring2018
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboQDifficulty = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtQuestion = new System.Windows.Forms.TextBox();
            this.lblLives = new System.Windows.Forms.Label();
            this.grpLives = new System.Windows.Forms.GroupBox();
            this.chkLife3 = new System.Windows.Forms.CheckBox();
            this.chkLife2 = new System.Windows.Forms.CheckBox();
            this.chkLife1 = new System.Windows.Forms.CheckBox();
            this.btnAnswer1 = new System.Windows.Forms.Button();
            this.btnAnswer2 = new System.Windows.Forms.Button();
            this.btnAnswer3 = new System.Windows.Forms.Button();
            this.btnAnswer4 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDifficulty = new System.Windows.Forms.Label();
            this.btnPlayAgain = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.grpLives.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboQDifficulty
            // 
            this.cboQDifficulty.AllowDrop = true;
            this.cboQDifficulty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboQDifficulty.FormattingEnabled = true;
            this.cboQDifficulty.ImeMode = System.Windows.Forms.ImeMode.On;
            this.cboQDifficulty.Items.AddRange(new object[] {
            "Easy",
            "Hard",
            "Impossible",
            "Regular"});
            this.cboQDifficulty.Location = new System.Drawing.Point(439, 57);
            this.cboQDifficulty.Margin = new System.Windows.Forms.Padding(2);
            this.cboQDifficulty.Name = "cboQDifficulty";
            this.cboQDifficulty.Size = new System.Drawing.Size(119, 21);
            this.cboQDifficulty.TabIndex = 0;
            this.cboQDifficulty.SelectedIndexChanged += new System.EventHandler(this.cboQDifficulty_SelectedIndexChanged);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(5, 9);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(318, 31);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "The Impossible Quiz";
            // 
            // txtQuestion
            // 
            this.txtQuestion.Cursor = System.Windows.Forms.Cursors.No;
            this.txtQuestion.Location = new System.Drawing.Point(11, 57);
            this.txtQuestion.Margin = new System.Windows.Forms.Padding(2);
            this.txtQuestion.Multiline = true;
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.ReadOnly = true;
            this.txtQuestion.Size = new System.Drawing.Size(298, 75);
            this.txtQuestion.TabIndex = 3;
            // 
            // lblLives
            // 
            this.lblLives.AutoSize = true;
            this.lblLives.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLives.Location = new System.Drawing.Point(314, 115);
            this.lblLives.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLives.Name = "lblLives";
            this.lblLives.Size = new System.Drawing.Size(71, 17);
            this.lblLives.TabIndex = 4;
            this.lblLives.Text = "Lives: ";
            // 
            // grpLives
            // 
            this.grpLives.Controls.Add(this.chkLife3);
            this.grpLives.Controls.Add(this.chkLife2);
            this.grpLives.Controls.Add(this.chkLife1);
            this.grpLives.Enabled = false;
            this.grpLives.Location = new System.Drawing.Point(384, 103);
            this.grpLives.Margin = new System.Windows.Forms.Padding(2);
            this.grpLives.Name = "grpLives";
            this.grpLives.Padding = new System.Windows.Forms.Padding(2);
            this.grpLives.Size = new System.Drawing.Size(174, 41);
            this.grpLives.TabIndex = 5;
            this.grpLives.TabStop = false;
            // 
            // chkLife3
            // 
            this.chkLife3.AutoSize = true;
            this.chkLife3.Location = new System.Drawing.Point(144, 16);
            this.chkLife3.Margin = new System.Windows.Forms.Padding(2);
            this.chkLife3.Name = "chkLife3";
            this.chkLife3.Size = new System.Drawing.Size(15, 14);
            this.chkLife3.TabIndex = 2;
            this.chkLife3.UseVisualStyleBackColor = true;
            // 
            // chkLife2
            // 
            this.chkLife2.AutoSize = true;
            this.chkLife2.Location = new System.Drawing.Point(77, 16);
            this.chkLife2.Margin = new System.Windows.Forms.Padding(2);
            this.chkLife2.Name = "chkLife2";
            this.chkLife2.Size = new System.Drawing.Size(15, 14);
            this.chkLife2.TabIndex = 1;
            this.chkLife2.UseVisualStyleBackColor = true;
            // 
            // chkLife1
            // 
            this.chkLife1.AutoSize = true;
            this.chkLife1.Location = new System.Drawing.Point(11, 16);
            this.chkLife1.Margin = new System.Windows.Forms.Padding(2);
            this.chkLife1.Name = "chkLife1";
            this.chkLife1.Size = new System.Drawing.Size(15, 14);
            this.chkLife1.TabIndex = 0;
            this.chkLife1.UseVisualStyleBackColor = true;
            // 
            // btnAnswer1
            // 
            this.btnAnswer1.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnswer1.Location = new System.Drawing.Point(11, 136);
            this.btnAnswer1.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer1.Name = "btnAnswer1";
            this.btnAnswer1.Size = new System.Drawing.Size(148, 59);
            this.btnAnswer1.TabIndex = 6;
            this.btnAnswer1.UseVisualStyleBackColor = true;
            // 
            // btnAnswer2
            // 
            this.btnAnswer2.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnswer2.Location = new System.Drawing.Point(163, 136);
            this.btnAnswer2.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer2.Name = "btnAnswer2";
            this.btnAnswer2.Size = new System.Drawing.Size(146, 59);
            this.btnAnswer2.TabIndex = 7;
            this.btnAnswer2.UseVisualStyleBackColor = true;
            // 
            // btnAnswer3
            // 
            this.btnAnswer3.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnswer3.Location = new System.Drawing.Point(11, 199);
            this.btnAnswer3.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer3.Name = "btnAnswer3";
            this.btnAnswer3.Size = new System.Drawing.Size(148, 62);
            this.btnAnswer3.TabIndex = 8;
            this.btnAnswer3.UseVisualStyleBackColor = true;
            // 
            // btnAnswer4
            // 
            this.btnAnswer4.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnswer4.Location = new System.Drawing.Point(163, 199);
            this.btnAnswer4.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnswer4.Name = "btnAnswer4";
            this.btnAnswer4.Size = new System.Drawing.Size(146, 62);
            this.btnAnswer4.TabIndex = 9;
            this.btnAnswer4.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(440, 154);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifficulty.Location = new System.Drawing.Point(314, 59);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(107, 17);
            this.lblDifficulty.TabIndex = 11;
            this.lblDifficulty.Text = "Difficulty:";
            // 
            // btnPlayAgain
            // 
            this.btnPlayAgain.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayAgain.Location = new System.Drawing.Point(440, 220);
            this.btnPlayAgain.Name = "btnPlayAgain";
            this.btnPlayAgain.Size = new System.Drawing.Size(118, 41);
            this.btnPlayAgain.TabIndex = 12;
            this.btnPlayAgain.Text = "Play Again";
            this.btnPlayAgain.UseVisualStyleBackColor = true;
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.Location = new System.Drawing.Point(317, 154);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(118, 107);
            this.btnPlay.TabIndex = 13;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 279);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnPlayAgain);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAnswer4);
            this.Controls.Add(this.btnAnswer3);
            this.Controls.Add(this.btnAnswer2);
            this.Controls.Add(this.btnAnswer1);
            this.Controls.Add(this.grpLives);
            this.Controls.Add(this.lblLives);
            this.Controls.Add(this.txtQuestion);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.cboQDifficulty);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Group Project 06";
            this.grpLives.ResumeLayout(false);
            this.grpLives.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboQDifficulty;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtQuestion;
        private System.Windows.Forms.Label lblLives;
        private System.Windows.Forms.GroupBox grpLives;
        private System.Windows.Forms.CheckBox chkLife3;
        private System.Windows.Forms.CheckBox chkLife2;
        private System.Windows.Forms.CheckBox chkLife1;
        private System.Windows.Forms.Button btnAnswer1;
        private System.Windows.Forms.Button btnAnswer2;
        private System.Windows.Forms.Button btnAnswer3;
        private System.Windows.Forms.Button btnAnswer4;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblDifficulty;
        private System.Windows.Forms.Button btnPlayAgain;
        private System.Windows.Forms.Button btnPlay;
    }
}

