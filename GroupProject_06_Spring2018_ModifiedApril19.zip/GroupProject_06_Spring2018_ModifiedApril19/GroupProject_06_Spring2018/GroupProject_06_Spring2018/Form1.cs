﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Media;

namespace GroupProject_06_Spring2018
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string[] QuestionsEasy = new string[cQuestionMax]; //creates array for a list of easy questions

        private string[] QuestionsEasyAnswers = new string[cMaxAnswers];

        private string[] QuestionsHard = new string[cQuestionMax]; //creates array for a list of hard questions

        private string[] QuestionsHardAnswers = new string[cMaxAnswers];

        private string[] QuestionsImpossible = new string[cQuestionMax]; //creates array for a list of regular questions

        private string[] QuestionsImpossibleAnswers = new string[cMaxAnswers];

        private string[] userName = new string[cMaxUsers]; //creates array to store up to 50 users

        private string[] selectedDifficulty = new string[cMaxUsers]; //creates array to store up to 50 users selected difficulty

        private int[] score = new int[cMaxUsers]; //creates array to store user scores

        private const int cMaxAnswers = 40; //creates constant variable that allows 40 answers in easy, hard, and impossible arrays

        private const int cMaxUsers = 50; //creates a constant number for parallel arrays

        private const int cQuestionMax = 10; //sets max question size for each difficulty

        private int cUserIndex = 0; //counter to keep track what question the user is on

        private int cIndex = 0; //Quesiton counter

        private int cScore = 0; //counter to keep track of users score


        private void populateEasyQuestions() //helper method for easy question set
        {
            QuestionsEasy[0] = "What is the color of the red ball?";
            QuestionsEasy[1] = "How many wheels does a bicycle have?";
            QuestionsEasy[2] = "How do the wheels on the bus go?";
            QuestionsEasy[3] = "How do you spell elephant?";
            QuestionsEasy[4] = "How many vowels are in this sentence?";
            QuestionsEasy[5] = "How many sides does a triangle have?";
            QuestionsEasy[6] = "Is the Earth flat?";
            QuestionsEasy[7] = "What is the color of Shrek?";
            QuestionsEasy[8] = "What sound does a cow make?";
            QuestionsEasy[9] = "How many questions did you previously answer?";
        }

        private void easyAnswers()
        {
            QuestionsEasyAnswers[0] = "Red"; //Correct #1
            QuestionsEasyAnswers[1] = "Yellow"; //Wrong #1
            QuestionsEasyAnswers[2] = "Blue"; //Wrong #1
            QuestionsEasyAnswers[3] = "Green"; //Wrong #1
            QuestionsEasyAnswers[4] = "Two"; //Correct #2
            QuestionsEasyAnswers[5] = "Three"; //Wrong #2
            QuestionsEasyAnswers[6] = "Four"; //Wrong #2
            QuestionsEasyAnswers[7] = "Twelve"; //Wrong #2
            QuestionsEasyAnswers[8] = "Round and round"; //Correct #3
            QuestionsEasyAnswers[9] = "Square and square"; //Wrong #3
            QuestionsEasyAnswers[10] = "Octagon and octagon"; //Wrong #3
            QuestionsEasyAnswers[11] = "Pentagram and pentagram"; //Wrong #3
            QuestionsEasyAnswers[12] = "Elephant"; //Correct #4
            QuestionsEasyAnswers[13] = "Elephunt"; //Wrong #4
            QuestionsEasyAnswers[14] = "Ellen DeGeneres"; //Wrong #4
            QuestionsEasyAnswers[15] = "Elephunk"; //Wrong #4
            QuestionsEasyAnswers[16] = "12"; //Correct #5
            QuestionsEasyAnswers[17] = "10"; //Wrong #5
            QuestionsEasyAnswers[18] = "8"; //Wrong #5
            QuestionsEasyAnswers[19] = "All of them"; //Wrong #5
            QuestionsEasyAnswers[20] = "3"; //Correct #6
            QuestionsEasyAnswers[21] = "13"; //Wrong #6
            QuestionsEasyAnswers[22] = "0"; //Wrong #6
            QuestionsEasyAnswers[23] = "6"; //Wrong #6
            QuestionsEasyAnswers[24] = "No"; //Correct #7
            QuestionsEasyAnswers[25] = "Due to electromagnetism, yes!"; //Wrong #7
            QuestionsEasyAnswers[26] = "Flat and round"; //Wrong #7
            QuestionsEasyAnswers[27] = "Sometimes"; //Wrong #7
            QuestionsEasyAnswers[28] = "Green"; //Correct #8
            QuestionsEasyAnswers[29] = "Pink"; //Wrong #8
            QuestionsEasyAnswers[30] = "Yellow"; //Wrong #8
            QuestionsEasyAnswers[31] = "Orange"; //Wrong #8
            QuestionsEasyAnswers[32] = "Moooooo!"; //Correct #9
            QuestionsEasyAnswers[33] = "Bark! Bark!"; //Wrong #9
            QuestionsEasyAnswers[34] = "Noooooo!"; //Wrong #9
            QuestionsEasyAnswers[35] = "Believe me!"; //Wrong #9
            QuestionsEasyAnswers[36] = "9"; //Correct #10
            QuestionsEasyAnswers[37] = "1"; //Wrong #10
            QuestionsEasyAnswers[38] = "25"; //Wrong #10
            QuestionsEasyAnswers[39] = "8"; //Wrong #10
        }

        private void populateHardQuestions() //helper method for hard question set
        {
            QuestionsHard[0] = "What is the boiling point of water in degrees fahrenheit?";
            QuestionsHard[1] = "What is the chemical compount of nitrous oxide?";
            QuestionsHard[2] = "Who is the founder of Amazon?";
            QuestionsHard[3] = "What is the Fundamental Theorem of Calculus?";
            QuestionsHard[4] = "Who is the last storyline boss in Dark Souls III?";
            QuestionsHard[5] = "What was the first game to implement an Easter egg?";
            QuestionsHard[6] = "Where was the hottest temperature on Earth recorded?";
            QuestionsHard[7] = "Who was the lead singer for Queen?";
            QuestionsHard[8] = "What did the first Artificial Intelligence program do?";
            QuestionsHard[9] = "What year was Purdue University founded?";
        }

        private void hardAnswers()
        {
            QuestionsHardAnswers[0] = "212"; //Correct #1
            QuestionsHardAnswers[1] = "201"; //Wrong #1
            QuestionsHardAnswers[2] = "312"; //Wrong #1
            QuestionsHardAnswers[3] = "237"; //Wrong #1
            QuestionsHardAnswers[4] = "N2O"; //Correct #2
            QuestionsHardAnswers[5] = "N2O2"; //Wrong #2
            QuestionsHardAnswers[6] = "N3O"; //Wrong #2
            QuestionsHardAnswers[7] = "4NO"; //Wrong #2
            QuestionsHardAnswers[8] = "Jeff Bezos"; //Correct #3
            QuestionsHardAnswers[9] = "Gabe Newell"; //Wrong #3
            QuestionsHardAnswers[10] = "Bill Gates"; //Wrong #3
            QuestionsHardAnswers[11] = "Tom Hampton"; //Wrong #3
            QuestionsHardAnswers[12] = "An anitderivitve, x, may be obtained as an intergral of x"; //Correct #4
            QuestionsHardAnswers[13] = "An anitderivitve, x, may be obtained as an derivative of x"; //Wrong #4
            QuestionsHardAnswers[14] = "An anitderivitve, x, may be obtained as an sequence # of x"; //Wrong #4
            QuestionsHardAnswers[15] = "An anitderivitve, x, may be obtained as an antiderivative of x"; //Wrong #4
            QuestionsHardAnswers[16] = "Soul of Cinder"; //Correct #5
            QuestionsHardAnswers[17] = "The Lord of Souls"; //Wrong #5
            QuestionsHardAnswers[18] = "The Great Eyed Beast"; //Wrong #5
            QuestionsHardAnswers[19] = "All of them merged into one"; //Wrong #5
            QuestionsHardAnswers[20] = "Adventure"; //Correct #6
            QuestionsHardAnswers[21] = "Ice Explorer"; //Wrong #6
            QuestionsHardAnswers[22] = "Pacman"; //Wrong #6
            QuestionsHardAnswers[23] = "Space Invaders"; //Wrong #6
            QuestionsHardAnswers[24] = "Freddy Mercury"; //Correct #7
            QuestionsHardAnswers[25] = "Jimmy Queen"; //Wrong #7
            QuestionsHardAnswers[26] = "Axel Rose"; //Wrong #7
            QuestionsHardAnswers[27] = "Dave Grohl"; //Wrong #7
            QuestionsHardAnswers[28] = "Death Valley, United States"; //Correct #8
            QuestionsHardAnswers[29] = "Mexico City, Mexico"; //Wrong #8
            QuestionsHardAnswers[30] = "Abu Dhabi, UAE"; //Wrong #8
            QuestionsHardAnswers[31] = "Giza, Egypt"; //Wrong #8
            QuestionsHardAnswers[32] = "Play checkers"; //Correct #9
            QuestionsHardAnswers[33] = "Play chess"; //Wrong #9
            QuestionsHardAnswers[34] = "Play tic-tac-toe"; //Wrong #9
            QuestionsHardAnswers[35] = "Play shogi"; //Wrong #9
            QuestionsHardAnswers[36] = "1869"; //Correct #10
            QuestionsHardAnswers[37] = "1849"; //Wrong #10
            QuestionsHardAnswers[38] = "1902"; //Wrong #10
            QuestionsHardAnswers[39] = "1871"; //Wrong #10
        }

        private void populateImpossibleQuestions() //helper method for impossible question set
        {
            QuestionsImpossible[0] = "How much wood could a woodchuck chuck if a woodchuck could chuck wood?";
            QuestionsImpossible[1] = "How many languages are estimated to be spoken in the world?";
            QuestionsImpossible[2] = "What is Purdue's basket ball all-time win percentage as of 2017?";
            QuestionsImpossible[3] = "At what time during the calendar year does the emperor penguin migrate?";
            QuestionsImpossible[4] = "How many lines of code did it take to created Elder Scrolls V: Skyrim?";
            QuestionsImpossible[5] = "What is the 200th digit of pi?";
            QuestionsImpossible[6] = "How many licks does it take to get to the center of a tootsie pop?";
            QuestionsImpossible[7] = "What was the first commercial aired on American television?";
            QuestionsImpossible[8] = "What is the color of a mirror?";
            QuestionsImpossible[9] = "What is Bob's favorite fruit?";
        }
        private void ImpossibleAnswers()
        {
            QuestionsImpossibleAnswers[0] = "25"; //Correct #1
            QuestionsImpossibleAnswers[1] = "24"; //Wrong #1
            QuestionsImpossibleAnswers[2] = "4"; //Wrong #1
            QuestionsImpossibleAnswers[3] = "3?"; //Wrong #1
            QuestionsImpossibleAnswers[4] = "7,106"; //Correct #2
            QuestionsImpossibleAnswers[5] = "3,516"; //Wrong #2
            QuestionsImpossibleAnswers[6] = "4,786"; //Wrong #2
            QuestionsImpossibleAnswers[7] = "15,768"; //Wrong #2
            QuestionsImpossibleAnswers[8] = "63.8%"; //Correct #3
            QuestionsImpossibleAnswers[9] = "63.5%"; //Wrong #3
            QuestionsImpossibleAnswers[10] = "63.1%"; //Wrong #3
            QuestionsImpossibleAnswers[11] = "63.9%"; //Wrong #3
            QuestionsImpossibleAnswers[12] = "March"; //Correct #4
            QuestionsImpossibleAnswers[13] = "April"; //Wrong #4
            QuestionsImpossibleAnswers[14] = "May"; //Wrong #4
            QuestionsImpossibleAnswers[15] = "June"; //Wrong #4
            QuestionsImpossibleAnswers[16] = "10,000,000"; //Correct #5
            QuestionsImpossibleAnswers[17] = "14,000,000"; //Wrong #5
            QuestionsImpossibleAnswers[18] = "15,000,000"; //Wrong #5
            QuestionsImpossibleAnswers[19] = "9,000,000"; //Wrong #5
            QuestionsImpossibleAnswers[20] = "6"; //Correct #6
            QuestionsImpossibleAnswers[21] = "9"; //Wrong #6
            QuestionsImpossibleAnswers[22] = "4"; //Wrong #6
            QuestionsImpossibleAnswers[23] = "7"; //Wrong #6
            QuestionsImpossibleAnswers[24] = "252"; //Correct #7
            QuestionsImpossibleAnswers[25] = "181"; //Wrong #7
            QuestionsImpossibleAnswers[26] = "320"; //Wrong #7
            QuestionsImpossibleAnswers[27] = "84"; //Wrong #7
            QuestionsImpossibleAnswers[28] = "Bulova Watch Co."; //Correct #8
            QuestionsImpossibleAnswers[29] = "Colgate Dental"; //Wrong #8
            QuestionsImpossibleAnswers[30] = "General Electric"; //Wrong #8
            QuestionsImpossibleAnswers[31] = "Kraft Cheese"; //Wrong #8
            QuestionsImpossibleAnswers[32] = "Green"; //Correct #9
            QuestionsImpossibleAnswers[33] = "Grey"; //Wrong #9
            QuestionsImpossibleAnswers[34] = "Blue"; //Wrong #9
            QuestionsImpossibleAnswers[35] = "Black"; //Wrong #9
            QuestionsImpossibleAnswers[36] = "Dragonfruit"; //Correct #10
            QuestionsImpossibleAnswers[37] = "Tomato"; //Wrong #10
            QuestionsImpossibleAnswers[38] = "Durian"; //Wrong #10
            QuestionsImpossibleAnswers[39] = "Rambutan"; //Wrong #10
        }
        private void repopulateEasyAnswers1()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[0]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[1]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[2]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[3]);
        }

        private void repopulateEasyAnswers2()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[7]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[6]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[5]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[4]);
        }
        private void repopulateEasyAnswers3()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[8]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[10]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[9]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[11]);
        }
        private void repopulateEasyAnswers4()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[14]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[13]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[12]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[15]);
        }
        private void repopulateEasyAnswers5()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[19]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[17]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[18]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[16]);
        }
        private void repopulateEasyAnswers6()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[23]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[21]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[22]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[20]);
        }
        private void repopulateEasyAnswers7()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[25]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[24]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[26]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[27]);
        }
        private void repopulateEasyAnswers8()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[30]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[29]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[28]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[31]);
        }
        private void repopulateEasyAnswers9()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[32]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[33]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[34]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[35]);
        }
        private void repopulateEasyAnswers10()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[39]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[37]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[38]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[36]);
        }

        private void repopulateHardQuestion1()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[1]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[0]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[3]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[2]);
        }
        private void repopulateHardQuestion2()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[4]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[6]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[5]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[7]);
        }
        private void repopulateHardQuestion3()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[9]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[8]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[10]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[11]);
        }
        private void repopulateHardQuestion4()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[12]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[13]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[15]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[14]);
        }
        private void repopulateHardQuestion5()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[16]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[17]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[19]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[18]);
        }
        private void repopulateHardQuestion6()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[20]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[22]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[21]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[23]);
        }
        private void repopulateHardQuestion7()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[24]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[26]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[25]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[27]);
        }
        private void repopulateHardQuestion8()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[28]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[31]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[29]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[30]);
        }
        private void repopulateHardQuestion9()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[32]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[34]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[33]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[35]);
        }
        private void repopulateHardQuestion10()
        {
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[36]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[37]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[39]);
            lstDisplayAnswers.Items.Add(QuestionsHardAnswers[38]);
        }

        private void repopulateImpossibleQuestion1()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[3]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[1]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[2]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[0]);
        }
        private void repopulateImpossibleQuestion2()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[5]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[7]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[6]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[4]);
        }
        private void repopulateImpossibleQuestion3()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[9]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[8]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[10]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[11]);
        }
        private void repopulateImpossibleQuestion4()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[13]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[12]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[14]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[15]);
        }
        private void repopulateImpossibleQuestion5()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[17]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[19]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[18]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[16]);
        }
        private void repopulateImpossibleQuestion6()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[21]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[23]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[22]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[20]);
        }
        private void repopulateImpossibleQuestion7()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[25]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[27]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[26]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[24]);
        }
        private void repopulateImpossibleQuestion8()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[30]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[29]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[28]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[31]);
        }
        private void repopulateImpossibleQuestion9()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[34]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[33]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[32]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[35]);
        }
        private void repopulateImpossibleQuestion10()
        {
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[38]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[39]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[37]);
            lstDisplayAnswers.Items.Add(QuestionsImpossibleAnswers[36]);
        }
        private void checkLife()
        {
            if (chkLife1.Checked == false)
            {
                chkLife1.Checked = true;
                return;
            }
            else if (chkLife2.Checked == false)
            {
                chkLife2.Checked = true;
                return;
            }
            else if (chkLife3.Checked == false)
            {
                chkLife3.Checked = true;
                EndGame();

            }

        }

        private void playIncorrectSound()
        {
            SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\Windows Critical Stop.wav");
            simpleSound.Play();
        }

        private void playCorrectSound()
        {
            SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\Windows Shutdown.wav");
            simpleSound.Play();
        }

        private void WriteToFile()
        {
            StreamWriter SW = null;
            int ctr;

            SW = new StreamWriter("SaveData.Txt");

            for (ctr = 1; ctr <= cUserIndex; ctr++)
            {
                SW.WriteLine(userName[ctr] + '\t' + selectedDifficulty[ctr] + '\t' + score[ctr]); //add to file
            }

            // Close the file:
            SW.Close();
        }


        private bool EndGame()
        {

            if (chkLife3.Checked == true)
            {
                DisplayMessage("No lives left. Game over!");
                lstDisplayAnswers.Items.Clear();
                txtQuestion.Clear();
                txtName.Focus();
                chkLife1.Checked = false;
                chkLife2.Checked = false;
                chkLife3.Checked = false;
                btnNextQuestion.Visible = false;
                btnPlay.Enabled = true;
                btnDisplayHighScores.Enabled = true;
                cboQDifficulty.Enabled = true;
                txtName.Enabled = true;
                score[cUserIndex] = cScore;
                cboQDifficulty.SelectedIndex = -1;
                WriteToFile();
                return true;
            }
            else
            {
                return false;
            }
        }



        private bool ValidateInput() //helper method to validate input
        {
            int aStringCheck;

            if (txtName.Text == "")
            {
                DisplayMessage("Please enter a name to play!");
                return false;
            }
            if (int.TryParse(txtName.Text, out aStringCheck) == true)
            {
                DisplayMessage("Please do not enter a number for a name!");
                return false;
            }
            if (cboQDifficulty.SelectedIndex != 0 && cboQDifficulty.SelectedIndex != 1 && cboQDifficulty.SelectedIndex != 2)
            {
                DisplayMessage("Please select a difficulty!");
                return false;
            }
            return true;
        }



        private void DisplayMessage(string message) //helper methods to call a message box
        {
            MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cboQDifficulty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtQuestion_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e) //Play button acts like an enter button. This button verifies that the user has entered a name for the game, and starts the the game itself.
        {

            if (ValidateInput() == false)
            {
                return;
            }
            else if (cUserIndex == cMaxUsers)
            {
                btnPlay.Enabled = false;
                DisplayMessage("The system is full! Please delete a user to play!");
                return;
            }
            else
            {


                if (cboQDifficulty.SelectedIndex == 0)
                {
                    cScore = 0;
                    cIndex = 0;
                    cUserIndex++;
                    populateEasyQuestions();
                    easyAnswers();
                    selectedDifficulty[cUserIndex] = "Easy";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    txtName.Enabled = false;
                    btnNextQuestion.Visible = true;
                    btnDisplayHighScores.Enabled = false;
                    txtName.Clear(); 
                      

                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[0]);
                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[1]);
                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[2]);
                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[3]);
                    txtQuestion.Text = QuestionsEasy[0];

                }
                if (cboQDifficulty.SelectedIndex == 1)
                {
                    selectedDifficulty[cUserIndex] = "Hard";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    txtName.Enabled = false;
                    btnNextQuestion.Visible = true;
                    txtName.Clear();
                    cUserIndex++;
                }
                if (cboQDifficulty.SelectedIndex == 2)
                {
                    selectedDifficulty[cUserIndex] = "Impossible";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    txtName.Enabled = false;
                    btnNextQuestion.Visible = true;
                    txtName.Clear();
                    cUserIndex++;
                }


            }


        }

        private void btnAnswer1_Click(object sender, EventArgs e)
        {

        }


        private void lstDisplayHighScore_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDisplayHighScores_Click(object sender, EventArgs e)
        {
            lstDisplayHighScore.Items.Clear();
            if (cUserIndex == 0) //checks if any users have been entered into the program
            {
                DisplayMessage("Display failed: Please play at least one game.");
                return;
            }
            else
            {
                lstDisplayHighScore.Items.Add("Name".PadRight(10) + "Difficulty".PadLeft(16) + "Score".PadLeft(16));
                lstDisplayHighScore.Items.Add("===============================================================");


                int ctr;
                for (ctr = 1; ctr <= cUserIndex; ctr++) //for loop to add array items in lstbox
                {
                    lstDisplayHighScore.Items.Add(userName[ctr].PadRight(10) + selectedDifficulty[ctr].PadLeft(10) + score[ctr].ToString(). PadLeft(18)); //displays names, difficulties, and scores in a uniform manner using the .PadRight and .PadLeft methods
                }

            }
        }

        private void btnSearch_Click(object sender, EventArgs e) //search for specified user //sequential search
        {
            // Check for empty array:
            if (cUserIndex == 0)
            {
                DisplayMessage("There has been no data entry.");
                return;
            }

            //Check txtName for existence:
            if (txtName.Text == "")
            {
                DisplayMessage("Please enter the search name.");
                txtName.Focus();
                return;
            }

            //Store the entered name in a string variable:
            string searchedName = txtName.Text.ToLower();

            int ctr;
            bool flag = false;

            // Searching for a unique name
            for (ctr = 0; ctr < cUserIndex; ctr++)
            {
                if (userName[ctr].ToLower() == searchedName)
                {
                    lstDisplayHighScore.Items.Clear();
                    lstDisplayHighScore.Items.Add(searchedName + " was found!");
                    lstDisplayHighScore.Items.Add("Student's Score: " + score[ctr]);
                    lstDisplayHighScore.Items.Add("Selected Difficulty" + selectedDifficulty[ctr]);

                    flag = true;
                    break;
                }

            }

            //Inform the user if search fails:
            if (flag == false)
            {
                DisplayMessage("Search failed.");

            }

        }

        private void lstDisplayAnswers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNextQuestion_Click(object sender, EventArgs e)
        {



            /////////////////////////////////////////////* START OF EASY DIFFICULTY *///////////////////////////////////////////////////////////////
            if (cboQDifficulty.SelectedIndex == 0)
            {


                if (cIndex == 0)
                {    

                    if (lstDisplayAnswers.SelectedIndex == 0) //1st question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers2();
                        txtQuestion.Text = QuestionsEasy[1];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 1)//1st Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers1();
                        txtQuestion.Text = QuestionsEasy[0];
                        checkLife();
                        EndGame();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //1st Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers1();
                        txtQuestion.Text = QuestionsEasy[0];
                        checkLife();
                        EndGame();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 3) //1st Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers1();
                        txtQuestion.Text = QuestionsEasy[0];
                        checkLife();
                        EndGame();
                    }
                    else if(lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers1();
                        return;
                    }

                }
                //completed question 1
               else if(cIndex == 1)
                {

                    if (lstDisplayAnswers.SelectedIndex == 3) //2nd question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers3();
                        txtQuestion.Text = QuestionsEasy[2];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 0) //2nd Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear(); 
                        repopulateEasyAnswers2();
                        txtQuestion.Text = QuestionsEasy[1];
                        EndGame();
                        checkLife();
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 1) //2nd Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers2();
                        txtQuestion.Text = QuestionsEasy[1];
                        EndGame();
                        checkLife();
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 2) //2nd Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers2();
                        txtQuestion.Text = QuestionsEasy[1];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers2();
                        return;
                    }

                }
                //completed question 2
                else if (cIndex == 2)
                {

                    if (lstDisplayAnswers.SelectedIndex == 0) //3rd question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers4();
                        txtQuestion.Text = QuestionsEasy[3];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 1)//3rd Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers3();
                        txtQuestion.Text = QuestionsEasy[2];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //3rd Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers3();
                        txtQuestion.Text = QuestionsEasy[2];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 3) //3rd Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers3();
                        txtQuestion.Text = QuestionsEasy[2];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers3();
                        return;
                    }
                }
                //Completed Question 3
                else if (cIndex == 3)
                {

                    if (lstDisplayAnswers.SelectedIndex == 2) //4th question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers5();
                        txtQuestion.Text = QuestionsEasy[4];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 1)//4th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers4();
                        txtQuestion.Text = QuestionsEasy[3];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 0) //4th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers4();
                        txtQuestion.Text = QuestionsEasy[3];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 3) //4th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers4();
                        txtQuestion.Text = QuestionsEasy[3];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers4();
                        return;
                    }
                }
                //Completed question 4
                else if (cIndex == 4)
                {

                    if (lstDisplayAnswers.SelectedIndex == 3) //5th question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers6();
                        txtQuestion.Text = QuestionsEasy[5];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 1)//5th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers5();
                        txtQuestion.Text = QuestionsEasy[4];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 0) //5th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers5();
                        txtQuestion.Text = QuestionsEasy[4];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //5th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers5();
                        txtQuestion.Text = QuestionsEasy[4];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers5();
                        return;
                    }
                }
                //Completed Question 5
                else if (cIndex == 5)
                {

                    if (lstDisplayAnswers.SelectedIndex == 3) //6th question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers7();
                        txtQuestion.Text = QuestionsEasy[6];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 1)//6th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers6();
                        txtQuestion.Text = QuestionsEasy[5];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 0) //6th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers6();
                        txtQuestion.Text = QuestionsEasy[5];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //5th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers6();
                        txtQuestion.Text = QuestionsEasy[5];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers6();
                        return;
                    }
                }
                //completed Question 6
                else if (cScore == 6)
                {

                    if (lstDisplayAnswers.SelectedIndex == 1) //7th question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers8();
                        txtQuestion.Text = QuestionsEasy[7];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 3)//7th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers7();
                        txtQuestion.Text = QuestionsEasy[6];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 0) //7th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers7();
                        txtQuestion.Text = QuestionsEasy[6];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //7th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers7();
                        txtQuestion.Text = QuestionsEasy[6];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers7();
                        return;
                    }
                }

                //completed Question 7
                else if (cIndex == 7)
                {

                    if (lstDisplayAnswers.SelectedIndex == 2) //8th question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers9();
                        txtQuestion.Text = QuestionsEasy[8];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 3)//8th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers8();
                        txtQuestion.Text = QuestionsEasy[7];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 0) //8th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers8();
                        txtQuestion.Text = QuestionsEasy[7];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 1) //8th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers8();
                        txtQuestion.Text = QuestionsEasy[7];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers8();
                        return;
                    }
                }

                //completed Question 8
                else if (cIndex == 8)
                {

                    if (lstDisplayAnswers.SelectedIndex == 0) //9th question : Correct answer
                    {
                        playCorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        cScore++;
                        cIndex++;
                        repopulateEasyAnswers10();
                        txtQuestion.Text = QuestionsEasy[9];
                    }

                    else if (lstDisplayAnswers.SelectedIndex == 3)//9th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers9();
                        txtQuestion.Text = QuestionsEasy[8];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //9th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers9();
                        txtQuestion.Text = QuestionsEasy[8];
                        EndGame();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 1) //9th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers9();
                        txtQuestion.Text = QuestionsEasy[8];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers9();
                        return;
                    }
                }

                //completed Question 9
                else if (cIndex == 9)
                {

                    if (lstDisplayAnswers.SelectedIndex == 3) //10th question : Correct answer
                    {
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        DisplayMessage("You Won!");
                        cScore++;
                        lstDisplayAnswers.Items.Clear();
                        txtQuestion.Clear();
                        txtName.Focus();
                        btnDisplayHighScores.Enabled = true;
                        chkLife1.Checked = false;
                        chkLife2.Checked = false;
                        chkLife3.Checked = false;
                        btnNextQuestion.Visible = false;
                        btnPlay.Enabled = true;
                        cboQDifficulty.Enabled = true;
                        txtName.Enabled = true;
                        cboQDifficulty.SelectedIndex = -1;
                        score[cUserIndex] = cScore;
                        WriteToFile();
                        

                    }

                    else if (lstDisplayAnswers.SelectedIndex == 0)//9th Question : 1st wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers10();
                        txtQuestion.Text = QuestionsEasy[9];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 2) //9th Question : 2nd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers10();
                        txtQuestion.Text = QuestionsEasy[9];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 1) //9th Question : 3rd wrong answer
                    {
                        playIncorrectSound();
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers10();
                        txtQuestion.Text = QuestionsEasy[9];
                        EndGame();
                        checkLife();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == -1)
                    {
                        lstDisplayAnswers.Items.Clear();
                        repopulateEasyAnswers10();
                        return;
                    }
                }
                /////////////////////////////////////////////* START OF HARD DIFFICULTY *///////////////////////////////////////////////////////////////
                if (cboQDifficulty.SelectedIndex == 1)
                {
                    if (cIndex == 0)
                    {

                        if (lstDisplayAnswers.SelectedIndex == 0) //1st question : Correct answer
                        {
                            playCorrectSound();
                            lstDisplayAnswers.Items.Clear();
                            txtQuestion.Clear();
                            cScore++;
                            cIndex++;
                            repopulateEasyAnswers2();
                            txtQuestion.Text = QuestionsHard[1];
                        }

                        else if (lstDisplayAnswers.SelectedIndex == 1)//1st Question : 1st wrong answer
                        {
                            playIncorrectSound();
                            lstDisplayAnswers.Items.Clear();
                            repopulateEasyAnswers1();
                            txtQuestion.Text = QuestionsHard[0];
                            checkLife();
                            EndGame();
                        }
                        else if (lstDisplayAnswers.SelectedIndex == 2) //1st Question : 2nd wrong answer
                        {
                            playIncorrectSound();
                            lstDisplayAnswers.Items.Clear();
                            repopulateEasyAnswers1();
                            txtQuestion.Text = QuestionsHard[0];
                            checkLife();
                            EndGame();
                        }
                        else if (lstDisplayAnswers.SelectedIndex == 3) //1st Question : 3rd wrong answer
                        {
                            playIncorrectSound();
                            lstDisplayAnswers.Items.Clear();
                            repopulateEasyAnswers1();
                            txtQuestion.Text = QuestionsHard[0];
                            checkLife();
                            EndGame();
                        }
                        else if (lstDisplayAnswers.SelectedIndex == -1)
                        {
                            lstDisplayAnswers.Items.Clear();
                            repopulateHAnswers1();
                            return;
                        }

                    }
                }
                if (cboQDifficulty.SelectedIndex == 2)
                {

                }
            }

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

         /*    StreamReader SR = null;
                string line;
                string[] parts;

                if (File.Exists("SaveData.txt") == false) //Check if save file exists
                {
                    DisplayMessage("A file does not exist!");
                    return;
                }
                SR = new StreamReader("SaveData.txt");

                while (SR.Peek() != -1) //disect data from save file
                {
                    line = SR.ReadLine();
                    parts = line.Split('\t');
                    userName[cUserIndex] = parts[0];
                    selectedDifficulty[cUserIndex] = parts[1];
                    cUserIndex++;
                }
                SR.Close(); */

        }
    }
}

    
