﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject_06_Spring2018
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string[] QuestionsEasy = new string[cQuestionMax]; //creates array for a list of easy questions

        private string[] QuestionsHard = new string[cQuestionMax]; //creates array for a list of hard questions

        private string[] QuestionsImpossible = new string[cQuestionMax]; //creates array for a list of regular questions

        private string[] userName = new string[cMaxUsers]; //creates array to store up to 50 users

        private string[] selectedDifficulty = new string[cMaxUsers]; //creates array to store up to 50 users selected difficulty

        private int[] score = new int[cMaxUsers]; //creates array to store user scores

        private const int cMaxUsers = 50; //creates a constant number for parallel arrays

        private const int cQuestionMax = 10; //sets max question size for each difficulty

        private int cQuestionIndex = 0; //counter for keepting track of question index

        private int cUserIndex = 0; //counter to keep track what question the user is on

        private int cScore = 0; //counter to keep track of users score

        private int cHealth = 3; //lives counter 

        private int mIndex = 0; //basic index
        private void populateEasyQuestions() //helper method for easy question set
        {
            QuestionsEasy[0] = "What is the color of the red ball?";
            QuestionsEasy[1] = "How many wheels does a bicycle have?";
            QuestionsEasy[2] = "How do the wheels on the bus go?";
            QuestionsEasy[3] = "How do you spell elephant?";
            QuestionsEasy[4] = "How many vowels are in this sentence?";
            QuestionsEasy[5] = "How many sides does a triangle have?";
            QuestionsEasy[6] = "Is the Earth flat?";
            QuestionsEasy[7] = "What is the color shrek?";
            QuestionsEasy[8] = "What sound does a cow make?";
            QuestionsEasy[9] = "How many questions did you previously answer?";
        }

        private void populateHardQuestions() //helper method for hard question set
        {
            QuestionsHard[0] = "What is the boiling point of water in degrees fahrenheit?";
            QuestionsHard[1] = "What is the chemical compount of nitrous oxide?";
            QuestionsHard[2] = "Who is the founder of Amazon?";
            QuestionsHard[3] = "What is the Fundamental Theorem of Calculus?";
            QuestionsHard[4] = "Who is the last storyline boss in Dark Souls III?";
            QuestionsHard[5] = "What was the first game to implement an Easter egg?";
            QuestionsHard[6] = "Where was the hottest temperature on Earth recorded?";
            QuestionsHard[7] = "Who was the lead singer for Queen?";
            QuestionsHard[8] = "What was the name of the first Artificial Intelligence program?";
            QuestionsHard[9] = "When was Purdue University founded?";
        }

        private void populateImpossibleQuestions() //helper method for impossible question set
        {
            QuestionsImpossible[0] = "How much wood could a woodchuck chuck if a woodchuck could chuck wood?";
            QuestionsImpossible[1] = "How many languages are estimated to be spoken in the world?";
            QuestionsImpossible[2] = "What is Purdue's basket ball all-time win percentage as of 2017?";
            QuestionsImpossible[3] = "At what time in the year do emperor penguins migrate?";
            QuestionsImpossible[4] = "How many lines of code did it take to created Elder Scrolls V: Skyrim?";
            QuestionsImpossible[5] = "What is the 200th digit of pi?";
            QuestionsImpossible[6] = "How many licks does it take to get to the center of a tootsie pop?";
            QuestionsImpossible[7] = "What was the first commercial aired on television?";
            QuestionsImpossible[8] = "What is the color of a mirror?";
            QuestionsImpossible[9] = "What is Bob's favorite fruit?";
        }

        private bool ValidateInput() //helper method to validate input
        {
            int aStringCheck;

            if (txtName.Text == "")
            {
                DisplayMessage("Please enter a name to play!");
                return false;
            }
            if (int.TryParse(txtName.Text, out aStringCheck) == true)
            {
                DisplayMessage("Please do not enter a number for a name!");
                return false;
            }
            if (cboQDifficulty.SelectedIndex != 0 && cboQDifficulty.SelectedIndex != 1 && cboQDifficulty.SelectedIndex != 2)
            {
                DisplayMessage("Please select a difficulty!");
                return false;
            }
            return true;
        }

        private void DisplayMessage(string message) //helper methods to call a message box
        {
            MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }

        private void cboQDifficulty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtQuestion_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e) //Play button acts like an enter button. This button verifies that the user has entered a name for the game, and starts the the game itself.
        {
            if (ValidateInput() == false)
            {
                return;
            }
            else if (cUserIndex == cMaxUsers)
            {
                btnPlay.Enabled = false;
                DisplayMessage("The system is full! Please delete a user to play!");
                return;
            }
            else
            {     
         

               if (cboQDifficulty.SelectedIndex == 0)
                {
                    selectedDifficulty[cUserIndex] = "Easy";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    btnPlayAgain.Enabled = false;
                    txtName.Enabled = false;
                    txtName.Clear();
                    cUserIndex++;
                  
                }
               if (cboQDifficulty.SelectedIndex == 1)
                {
                    selectedDifficulty[cUserIndex] = "Hard";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    btnPlayAgain.Enabled = false;
                    txtName.Enabled = false;
                    txtName.Clear();
                    cUserIndex++;
                }
               if (cboQDifficulty.SelectedIndex == 2)
                {
                    selectedDifficulty[cUserIndex] = "Impossible";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    btnPlayAgain.Enabled = false;
                    txtName.Enabled = false;
                    txtName.Clear();
                    cUserIndex++;
                }

               
            }
            
            
        }

        private void btnAnswer1_Click(object sender, EventArgs e)
        {

        }

     
        private void lstDisplayHighScore_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDisplayHighScores_Click(object sender, EventArgs e)
        {
            lstDisplayHighScore.Items.Clear();
            if (cUserIndex == 0) //checks if any users have been entered into the program
            {
                DisplayMessage("Display failed: Please enter at least one name & GPA into the program");
                return;
            }
            else
            {
                lstDisplayHighScore.Items.Add("Name".PadRight(10) + "Difficulty".PadLeft(16) + "Score".PadLeft(16));
                lstDisplayHighScore.Items.Add("===============================================================");


                int ctr;
                for (ctr = 0; ctr < cUserIndex; ctr++) //for loop to add array items in lstbox
                {
                    lstDisplayHighScore.Items.Add(userName[ctr].PadRight(10) + selectedDifficulty[ctr].PadLeft(10) + score[ctr].ToString().PadLeft(18)); //displays names, difficulties, and scores in a uniform manner using the .PadRight and .PadLeft methods
                }

            }
        }

        private void btnSearch_Click(object sender, EventArgs e) //search for specified user //sequential search
        {
            // Check for empty array:
            if (mIndex == 0)
            {
                DisplayMessage("There has been no data entry.");
                return;
            }

            //Check txtName for existence:
            if (txtName.Text == "")
            {
                DisplayMessage("Please enter the search name.");
                txtName.Focus();
                return;
            }

            //Store the entered name in a string variable:
            string searchedName = txtName.Text.ToLower();

            int ctr;
            bool flag = false;

            // Searching for a unique name
            for (ctr = 0; ctr < mIndex; ctr++)
            {
                if (userName[ctr].ToLower() == searchedName)
                {
                    lstDisplayHighScore.Items.Clear();
                    lstDisplayHighScore.Items.Add(searchedName + " was found!");
                    lstDisplayHighScore.Items.Add("Student's Score: " + score[ctr]);
                    lstDisplayHighScore.Items.Add("Selected Difficulty" + selectedDifficulty[ctr]);

                    flag = true;
                    break;
                }

            }

            //Inform the user if search fails:
            if (flag == false)
            {
                DisplayMessage("Search failed.");

            }

            /* populateEasyQuestions();
                   txtQuestion.Text = QuestionsEasy[0];
                   btnAnswer1.Text = "Red";
                   btnAnswer2.Text = "Blue";
                   btnAnswer3.Text = "Green";
                   btnAnswer4.Text = "Yellow";
                   */
        }
    }
    }
