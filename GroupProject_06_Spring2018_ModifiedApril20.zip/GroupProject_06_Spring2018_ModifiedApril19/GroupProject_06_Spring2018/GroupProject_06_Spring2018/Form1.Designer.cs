﻿namespace GroupProject_06_Spring2018
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboQDifficulty = new System.Windows.Forms.ComboBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtQuestion = new System.Windows.Forms.TextBox();
            this.lblLives = new System.Windows.Forms.Label();
            this.grpLives = new System.Windows.Forms.GroupBox();
            this.chkLife3 = new System.Windows.Forms.CheckBox();
            this.chkLife2 = new System.Windows.Forms.CheckBox();
            this.chkLife1 = new System.Windows.Forms.CheckBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDifficulty = new System.Windows.Forms.Label();
            this.btnPlay = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lstDisplayHighScore = new System.Windows.Forms.ListBox();
            this.btnSortLowToHigh = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtNameSearch = new System.Windows.Forms.TextBox();
            this.btnSortHighToLow = new System.Windows.Forms.Button();
            this.btnDeleteSelected = new System.Windows.Forms.Button();
            this.btnDisplayHighScores = new System.Windows.Forms.Button();
            this.lstDisplayAnswers = new System.Windows.Forms.ListBox();
            this.btnNextQuestion = new System.Windows.Forms.Button();
            this.grpLives.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboQDifficulty
            // 
            this.cboQDifficulty.AllowDrop = true;
            this.cboQDifficulty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboQDifficulty.FormattingEnabled = true;
            this.cboQDifficulty.ImeMode = System.Windows.Forms.ImeMode.On;
            this.cboQDifficulty.Items.AddRange(new object[] {
            "Easy",
            "Hard",
            "Impossible"});
            this.cboQDifficulty.Location = new System.Drawing.Point(658, 88);
            this.cboQDifficulty.Name = "cboQDifficulty";
            this.cboQDifficulty.Size = new System.Drawing.Size(176, 28);
            this.cboQDifficulty.TabIndex = 0;
            this.cboQDifficulty.SelectedIndexChanged += new System.EventHandler(this.cboQDifficulty_SelectedIndexChanged);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Courier New", 18.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(16, 14);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(456, 43);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "The Impossible Quiz";
            // 
            // txtQuestion
            // 
            this.txtQuestion.Cursor = System.Windows.Forms.Cursors.No;
            this.txtQuestion.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuestion.Location = new System.Drawing.Point(16, 88);
            this.txtQuestion.Multiline = true;
            this.txtQuestion.Name = "txtQuestion";
            this.txtQuestion.ReadOnly = true;
            this.txtQuestion.Size = new System.Drawing.Size(445, 150);
            this.txtQuestion.TabIndex = 3;
            this.txtQuestion.TextChanged += new System.EventHandler(this.txtQuestion_TextChanged);
            // 
            // lblLives
            // 
            this.lblLives.AutoSize = true;
            this.lblLives.Font = new System.Drawing.Font("Courier New", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLives.Location = new System.Drawing.Point(471, 197);
            this.lblLives.Name = "lblLives";
            this.lblLives.Size = new System.Drawing.Size(103, 25);
            this.lblLives.TabIndex = 4;
            this.lblLives.Text = "Lives: ";
            // 
            // grpLives
            // 
            this.grpLives.Controls.Add(this.chkLife3);
            this.grpLives.Controls.Add(this.chkLife2);
            this.grpLives.Controls.Add(this.chkLife1);
            this.grpLives.Enabled = false;
            this.grpLives.Location = new System.Drawing.Point(578, 177);
            this.grpLives.Name = "grpLives";
            this.grpLives.Size = new System.Drawing.Size(261, 63);
            this.grpLives.TabIndex = 5;
            this.grpLives.TabStop = false;
            // 
            // chkLife3
            // 
            this.chkLife3.AutoSize = true;
            this.chkLife3.Location = new System.Drawing.Point(216, 25);
            this.chkLife3.Name = "chkLife3";
            this.chkLife3.Size = new System.Drawing.Size(22, 21);
            this.chkLife3.TabIndex = 2;
            this.chkLife3.UseVisualStyleBackColor = true;
            // 
            // chkLife2
            // 
            this.chkLife2.AutoSize = true;
            this.chkLife2.Location = new System.Drawing.Point(116, 25);
            this.chkLife2.Name = "chkLife2";
            this.chkLife2.Size = new System.Drawing.Size(22, 21);
            this.chkLife2.TabIndex = 1;
            this.chkLife2.UseVisualStyleBackColor = true;
            // 
            // chkLife1
            // 
            this.chkLife1.AutoSize = true;
            this.chkLife1.Location = new System.Drawing.Point(16, 25);
            this.chkLife1.Name = "chkLife1";
            this.chkLife1.Size = new System.Drawing.Size(22, 21);
            this.chkLife1.TabIndex = 0;
            this.chkLife1.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(662, 311);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(177, 98);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifficulty.Location = new System.Drawing.Point(471, 91);
            this.lblDifficulty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(166, 27);
            this.lblDifficulty.TabIndex = 11;
            this.lblDifficulty.Text = "Difficulty:";
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.Location = new System.Drawing.Point(476, 438);
            this.btnPlay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(362, 98);
            this.btnPlay.TabIndex = 13;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(12, 262);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(306, 27);
            this.lblName.TabIndex = 14;
            this.lblName.Text = "Enter a name to play!";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(314, 262);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(148, 26);
            this.txtName.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(339, 557);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 33);
            this.label2.TabIndex = 16;
            this.label2.Text = "Highscores";
            // 
            // lstDisplayHighScore
            // 
            this.lstDisplayHighScore.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDisplayHighScore.FormattingEnabled = true;
            this.lstDisplayHighScore.ItemHeight = 27;
            this.lstDisplayHighScore.Location = new System.Drawing.Point(16, 663);
            this.lstDisplayHighScore.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lstDisplayHighScore.Name = "lstDisplayHighScore";
            this.lstDisplayHighScore.Size = new System.Drawing.Size(816, 139);
            this.lstDisplayHighScore.TabIndex = 17;
            this.lstDisplayHighScore.SelectedIndexChanged += new System.EventHandler(this.lstDisplayHighScore_SelectedIndexChanged);
            // 
            // btnSortLowToHigh
            // 
            this.btnSortLowToHigh.Location = new System.Drawing.Point(16, 846);
            this.btnSortLowToHigh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSortLowToHigh.Name = "btnSortLowToHigh";
            this.btnSortLowToHigh.Size = new System.Drawing.Size(156, 35);
            this.btnSortLowToHigh.TabIndex = 18;
            this.btnSortLowToHigh.Text = "Sort Low to High";
            this.btnSortLowToHigh.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(345, 846);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(153, 35);
            this.btnSearch.TabIndex = 19;
            this.btnSearch.Text = "Search Name:";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtNameSearch
            // 
            this.txtNameSearch.Location = new System.Drawing.Point(507, 849);
            this.txtNameSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNameSearch.Name = "txtNameSearch";
            this.txtNameSearch.Size = new System.Drawing.Size(130, 26);
            this.txtNameSearch.TabIndex = 20;
            // 
            // btnSortHighToLow
            // 
            this.btnSortHighToLow.Location = new System.Drawing.Point(182, 846);
            this.btnSortHighToLow.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSortHighToLow.Name = "btnSortHighToLow";
            this.btnSortHighToLow.Size = new System.Drawing.Size(154, 35);
            this.btnSortHighToLow.TabIndex = 21;
            this.btnSortHighToLow.Text = "Sort High to Low";
            this.btnSortHighToLow.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSelected
            // 
            this.btnDeleteSelected.Location = new System.Drawing.Point(648, 846);
            this.btnDeleteSelected.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDeleteSelected.Name = "btnDeleteSelected";
            this.btnDeleteSelected.Size = new System.Drawing.Size(186, 35);
            this.btnDeleteSelected.TabIndex = 22;
            this.btnDeleteSelected.Text = "Delete Selected User";
            this.btnDeleteSelected.UseVisualStyleBackColor = true;
            // 
            // btnDisplayHighScores
            // 
            this.btnDisplayHighScores.Location = new System.Drawing.Point(333, 609);
            this.btnDisplayHighScores.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDisplayHighScores.Name = "btnDisplayHighScores";
            this.btnDisplayHighScores.Size = new System.Drawing.Size(186, 35);
            this.btnDisplayHighScores.TabIndex = 23;
            this.btnDisplayHighScores.Text = "Display High Scores";
            this.btnDisplayHighScores.UseVisualStyleBackColor = true;
            this.btnDisplayHighScores.Click += new System.EventHandler(this.btnDisplayHighScores_Click);
            // 
            // lstDisplayAnswers
            // 
            this.lstDisplayAnswers.FormattingEnabled = true;
            this.lstDisplayAnswers.ItemHeight = 20;
            this.lstDisplayAnswers.Location = new System.Drawing.Point(18, 311);
            this.lstDisplayAnswers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lstDisplayAnswers.Name = "lstDisplayAnswers";
            this.lstDisplayAnswers.Size = new System.Drawing.Size(444, 224);
            this.lstDisplayAnswers.TabIndex = 24;
            this.lstDisplayAnswers.SelectedIndexChanged += new System.EventHandler(this.lstDisplayAnswers_SelectedIndexChanged);
            // 
            // btnNextQuestion
            // 
            this.btnNextQuestion.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextQuestion.Location = new System.Drawing.Point(476, 311);
            this.btnNextQuestion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnNextQuestion.Name = "btnNextQuestion";
            this.btnNextQuestion.Size = new System.Drawing.Size(177, 98);
            this.btnNextQuestion.TabIndex = 25;
            this.btnNextQuestion.Text = "Next Question";
            this.btnNextQuestion.UseVisualStyleBackColor = true;
            this.btnNextQuestion.Visible = false;
            this.btnNextQuestion.Click += new System.EventHandler(this.btnNextQuestion_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 900);
            this.Controls.Add(this.btnNextQuestion);
            this.Controls.Add(this.lstDisplayAnswers);
            this.Controls.Add(this.btnDisplayHighScores);
            this.Controls.Add(this.btnDeleteSelected);
            this.Controls.Add(this.btnSortHighToLow);
            this.Controls.Add(this.txtNameSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnSortLowToHigh);
            this.Controls.Add(this.lstDisplayHighScore);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpLives);
            this.Controls.Add(this.lblLives);
            this.Controls.Add(this.txtQuestion);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.cboQDifficulty);
            this.Name = "Form1";
            this.Text = "Group Project 06";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpLives.ResumeLayout(false);
            this.grpLives.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboQDifficulty;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtQuestion;
        private System.Windows.Forms.Label lblLives;
        private System.Windows.Forms.GroupBox grpLives;
        private System.Windows.Forms.CheckBox chkLife3;
        private System.Windows.Forms.CheckBox chkLife2;
        private System.Windows.Forms.CheckBox chkLife1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblDifficulty;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lstDisplayHighScore;
        private System.Windows.Forms.Button btnSortLowToHigh;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtNameSearch;
        private System.Windows.Forms.Button btnSortHighToLow;
        private System.Windows.Forms.Button btnDeleteSelected;
        private System.Windows.Forms.Button btnHighScoreDisplay;
        private System.Windows.Forms.Button btnDisplayHighScores;
        private System.Windows.Forms.ListBox lstDisplayAnswers;
        private System.Windows.Forms.Button btnNextQuestion;
    }
}

