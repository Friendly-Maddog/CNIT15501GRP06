﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject_06_Spring2018
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string[] QuestionsEasy = new string[cQuestionMax]; //creates array for a list of easy questions

        private string[] QuestionsEasyAnswers = new string[cMaxAnswers];

        private string[] QuestionsHard = new string[cQuestionMax]; //creates array for a list of hard questions

        private string[] QuestionsHardAnswers = new string[cMaxAnswers];

        private string[] QuestionsImpossible = new string[cQuestionMax]; //creates array for a list of regular questions

        private string[] QuestionsImpossibleAnswers = new string[cMaxAnswers];

        private string[] userName = new string[cMaxUsers]; //creates array to store up to 50 users

        private string[] selectedDifficulty = new string[cMaxUsers]; //creates array to store up to 50 users selected difficulty

        private int[] score = new int[cMaxUsers]; //creates array to store user scores

        private const int cMaxAnswers = 40; //creates constant variable that allows 40 answers in easy, hard, and impossible arrays

        private const int cMaxUsers = 50; //creates a constant number for parallel arrays

        private const int cQuestionMax = 10; //sets max question size for each difficulty

        private int cQuestionIndex = 0; //counter for keepting track of question index

        private int cUserIndex = 0; //counter to keep track what question the user is on

        private int cScore = 0; //counter to keep track of users score

        private int cHealth = 3; //lives counter 

        private int mIndex = 0; //basic index



        private void populateEasyQuestions() //helper method for easy question set
        {
            QuestionsEasy[0] = "What is the color of the red ball?";
            QuestionsEasy[1] = "How many wheels does a bicycle have?";
            QuestionsEasy[2] = "How do the wheels on the bus go?";
            QuestionsEasy[3] = "How do you spell elephant?";
            QuestionsEasy[4] = "How many vowels are in this sentence?";
            QuestionsEasy[5] = "How many sides does a triangle have?";
            QuestionsEasy[6] = "Is the Earth flat?";
            QuestionsEasy[7] = "What is the color of Shrek?";
            QuestionsEasy[8] = "What sound does a cow make?";
            QuestionsEasy[9] = "How many questions did you previously answer?";
        }

        private void easyAnswers()
        {
            QuestionsEasyAnswers[0] = "Red"; //Correct #1
            QuestionsEasyAnswers[1] = "Yellow"; //Wrong #1
            QuestionsEasyAnswers[2] = "Blue"; //Wrong #1
            QuestionsEasyAnswers[3] = "Green"; //Wrong #1
            QuestionsEasyAnswers[4] = "Two"; //Correct #2
            QuestionsEasyAnswers[5] = "Three"; //Wrong #2
            QuestionsEasyAnswers[6] = "Four"; //Wrong #2
            QuestionsEasyAnswers[7] = "Twelve"; //Wrong #2
            QuestionsEasyAnswers[8] = "Round and round"; //Correct #3
            QuestionsEasyAnswers[9] = "Square and square"; //Wrong #3
            QuestionsEasyAnswers[10] = "Octagon and octagon"; //Wrong #3
            QuestionsEasyAnswers[11] = "Pentagram and pentagram"; //Wrong #3
            QuestionsEasyAnswers[12] = "Elephant"; //Correct #4
            QuestionsEasyAnswers[13] = "Elephunt"; //Wrong #4
            QuestionsEasyAnswers[14] = "Ellen DeGeneres"; //Wrong #4
            QuestionsEasyAnswers[15] = "Elephunk"; //Wrong #4
            QuestionsEasyAnswers[16] = "12"; //Correct #5
            QuestionsEasyAnswers[17] = "10"; //Wrong #5
            QuestionsEasyAnswers[18] = "8"; //Wrong #5
            QuestionsEasyAnswers[19] = "All of them"; //Wrong #5
            QuestionsEasyAnswers[20] = "3"; //Correct #6
            QuestionsEasyAnswers[21] = "13"; //Wrong #6
            QuestionsEasyAnswers[22] = "None"; //Wrong #6
            QuestionsEasyAnswers[23] = "Six"; //Wrong #6
            QuestionsEasyAnswers[24] = "No"; //Correct #7
            QuestionsEasyAnswers[25] = "Due to electromagnetism, yes!"; //Wrong #7
            QuestionsEasyAnswers[26] = "Flat and round"; //Wrong #7
            QuestionsEasyAnswers[27] = "Sometimes"; //Wrong #7
            QuestionsEasyAnswers[28] = "Green"; //Correct #8
            QuestionsEasyAnswers[29] = "Pink"; //Wrong #8
            QuestionsEasyAnswers[30] = "Yellow"; //Wrong #8
            QuestionsEasyAnswers[31] = "Orange"; //Wrong #8
            QuestionsEasyAnswers[32] = "Moooooo!"; //Correct #9
            QuestionsEasyAnswers[33] = "Bark! Bark!"; //Wrong #9
            QuestionsEasyAnswers[34] = "Noooooo!"; //Wrong #9
            QuestionsEasyAnswers[35] = "Believe me!"; //Wrong #9
            QuestionsEasyAnswers[36] = "9"; //Correct #10
            QuestionsEasyAnswers[37] = "1"; //Wrong #10
            QuestionsEasyAnswers[38] = "25"; //Wrong #10
            QuestionsEasyAnswers[39] = "8"; //Wrong #10
        }

        private void populateHardQuestions() //helper method for hard question set
        {
            QuestionsHard[0] = "What is the boiling point of water in degrees fahrenheit?";
            QuestionsHard[1] = "What is the chemical compount of nitrous oxide?";
            QuestionsHard[2] = "Who is the founder of Amazon?";
            QuestionsHard[3] = "What is the Fundamental Theorem of Calculus?";
            QuestionsHard[4] = "Who is the last storyline boss in Dark Souls III?";
            QuestionsHard[5] = "What was the first game to implement an Easter egg?";
            QuestionsHard[6] = "Where was the hottest temperature on Earth recorded?";
            QuestionsHard[7] = "Who was the lead singer for Queen?";
            QuestionsHard[8] = "What was the name of the first Artificial Intelligence program?";
            QuestionsHard[9] = "When was Purdue University founded?";
        }


        private void populateImpossibleQuestions() //helper method for impossible question set
        {
            QuestionsImpossible[0] = "How much wood could a woodchuck chuck if a woodchuck could chuck wood?";
            QuestionsImpossible[1] = "How many languages are estimated to be spoken in the world?";
            QuestionsImpossible[2] = "What is Purdue's basket ball all-time win percentage as of 2017?";
            QuestionsImpossible[3] = "At what time in the year do emperor penguins migrate?";
            QuestionsImpossible[4] = "How many lines of code did it take to created Elder Scrolls V: Skyrim?";
            QuestionsImpossible[5] = "What is the 200th digit of pi?";
            QuestionsImpossible[6] = "How many licks does it take to get to the center of a tootsie pop?";
            QuestionsImpossible[7] = "What was the first commercial aired on television?";
            QuestionsImpossible[8] = "What is the color of a mirror?";
            QuestionsImpossible[9] = "What is Bob's favorite fruit?";
        }

        private void answerResponse()
        {
            lstDisplayAnswers.Items.Clear();
            DisplayMessage("Incorrect answer!");
            cHealth++;
            checkLife();
            EndGame();
        }

        private void repopulatequestion2()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[7]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[6]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[5]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[4]);
        }

        private void repopulatequestion3()
        {
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[8]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[10]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[9]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[11]);
        }

        private void checkLife()
        {
            if (chkLife1.Checked == false)
            {
                chkLife1.Checked = true;
                return;
            }
            else if (chkLife2.Checked == false)
            {
                chkLife2.Checked = true;
                return;
            }
            else if (chkLife3.Checked == false)
            {
                chkLife3.Checked = true;
                return;

            }

        }



        private bool EndGame()
        {

            if (chkLife3.Checked == true)
            {
                DisplayMessage("No lives left. Game over!");
                lstDisplayAnswers.Items.Clear();
                txtQuestion.Clear();
                txtName.Focus();
                return true;
            }
            else
            {
                return false;
            }
        }



        private bool ValidateInput() //helper method to validate input
        {
            int aStringCheck;

            if (txtName.Text == "")
            {
                DisplayMessage("Please enter a name to play!");
                return false;
            }
            if (int.TryParse(txtName.Text, out aStringCheck) == true)
            {
                DisplayMessage("Please do not enter a number for a name!");
                return false;
            }
            if (cboQDifficulty.SelectedIndex != 0 && cboQDifficulty.SelectedIndex != 1 && cboQDifficulty.SelectedIndex != 2)
            {
                DisplayMessage("Please select a difficulty!");
                return false;
            }
            return true;
        }



        private void DisplayMessage(string message) //helper methods to call a message box
        {
            MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }

        private void cboQDifficulty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtQuestion_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e) //Play button acts like an enter button. This button verifies that the user has entered a name for the game, and starts the the game itself.
        {


            if (ValidateInput() == false)
            {
                return;
            }
            else if (cUserIndex == cMaxUsers)
            {
                btnPlay.Enabled = false;
                DisplayMessage("The system is full! Please delete a user to play!");
                return;
            }
            else
            {


                if (cboQDifficulty.SelectedIndex == 0)
                {
                    populateEasyQuestions();
                    easyAnswers();
                    selectedDifficulty[cUserIndex] = "Easy";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    txtName.Enabled = false;
                    btnNextQuestion.Visible = true;
                    txtName.Clear();
                    cUserIndex++;

                    txtQuestion.Text = QuestionsEasy[0];

                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[0]);
                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[1]);
                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[2]);
                    lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[3]);


                }
                if (cboQDifficulty.SelectedIndex == 1)
                {
                    selectedDifficulty[cUserIndex] = "Hard";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    txtName.Enabled = false;
                    btnNextQuestion.Visible = true;
                    txtName.Clear();
                    cUserIndex++;
                }
                if (cboQDifficulty.SelectedIndex == 2)
                {
                    selectedDifficulty[cUserIndex] = "Impossible";
                    userName[cUserIndex] = txtName.Text;
                    cboQDifficulty.Enabled = false;
                    btnPlay.Enabled = false;
                    txtName.Enabled = false;
                    btnNextQuestion.Visible = true;
                    txtName.Clear();
                    cUserIndex++;
                }


            }


        }

        private void btnAnswer1_Click(object sender, EventArgs e)
        {

        }


        private void lstDisplayHighScore_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDisplayHighScores_Click(object sender, EventArgs e)
        {
            lstDisplayHighScore.Items.Clear();
            if (cUserIndex == 0) //checks if any users have been entered into the program
            {
                DisplayMessage("Display failed: Please enter at least one name & GPA into the program");
                return;
            }
            else
            {
                lstDisplayHighScore.Items.Add("Name".PadRight(10) + "Difficulty".PadLeft(16) + "Score".PadLeft(16));
                lstDisplayHighScore.Items.Add("===============================================================");


                int ctr;
                for (ctr = 0; ctr < cUserIndex; ctr++) //for loop to add array items in lstbox
                {
                    lstDisplayHighScore.Items.Add(userName[ctr].PadRight(10) + selectedDifficulty[ctr].PadLeft(10) + cScore.ToString().PadLeft(18)); //displays names, difficulties, and scores in a uniform manner using the .PadRight and .PadLeft methods
                }

            }
        }

        private void btnSearch_Click(object sender, EventArgs e) //search for specified user //sequential search
        {
            // Check for empty array:
            if (mIndex == 0)
            {
                DisplayMessage("There has been no data entry.");
                return;
            }

            //Check txtName for existence:
            if (txtName.Text == "")
            {
                DisplayMessage("Please enter the search name.");
                txtName.Focus();
                return;
            }

            //Store the entered name in a string variable:
            string searchedName = txtName.Text.ToLower();

            int ctr;
            bool flag = false;

            // Searching for a unique name
            for (ctr = 0; ctr < mIndex; ctr++)
            {
                if (userName[ctr].ToLower() == searchedName)
                {
                    lstDisplayHighScore.Items.Clear();
                    lstDisplayHighScore.Items.Add(searchedName + " was found!");
                    lstDisplayHighScore.Items.Add("Student's Score: " + score[ctr]);
                    lstDisplayHighScore.Items.Add("Selected Difficulty" + selectedDifficulty[ctr]);

                    flag = true;
                    break;
                }

            }

            //Inform the user if search fails:
            if (flag == false)
            {
                DisplayMessage("Search failed.");

            }

            /* populateEasyQuestions();
                   txtQuestion.Text = QuestionsEasy[0];
                   btnAnswer1.Text = "Red";
                   btnAnswer2.Text = "Blue";
                   btnAnswer3.Text = "Green";
                   btnAnswer4.Text = "Yellow";
                   */
        }

        private void lstDisplayAnswers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNextQuestion_Click(object sender, EventArgs e)
        {

            populateEasyQuestions();
            easyAnswers();
            populateHardQuestions();
            populateImpossibleQuestions();


            txtQuestion.Text = QuestionsEasy[0];

            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[0]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[1]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[2]);
            lstDisplayAnswers.Items.Add(QuestionsEasyAnswers[3]);

            if (cboQDifficulty.SelectedIndex == 0)
            {
                if (lstDisplayAnswers.SelectedIndex == 0)
                {
                    lstDisplayAnswers.Items.Clear();
                    DisplayMessage("Correct!");
                    cScore++;
                    repopulatequestion2();
                    txtQuestion.Text = QuestionsEasy[1];

                    if (lstDisplayAnswers.SelectedIndex == 4)
                    {
                        DisplayMessage("Correct!");
                        cScore++;
                        repopulatequestion3();
                        txtQuestion.Text = QuestionsEasy[2];
                        if (lstDisplayAnswers.SelectedIndex == 4)
                        {
                            DisplayMessage("Correct!");
                            cScore++;
                        }
                        else if (lstDisplayAnswers.SelectedIndex == 5)
                        {
                            answerResponse();
                            repopulatequestion3();
                            txtQuestion.Text = QuestionsEasy[2];
                        }
                        else if (lstDisplayAnswers.SelectedIndex == 6)
                        {
                            answerResponse();
                            repopulatequestion3();
                            txtQuestion.Text = QuestionsEasy[2];
                        }
                        else if (lstDisplayAnswers.SelectedIndex == 7)
                        {
                            answerResponse();
                            repopulatequestion3();
                            txtQuestion.Text = QuestionsEasy[2];
                        }
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 5)
                    {
                        answerResponse();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 6)
                    {
                        answerResponse();
                    }
                    else if (lstDisplayAnswers.SelectedIndex == 7)
                    {
                        answerResponse();
                    }


                }
                else if (lstDisplayAnswers.SelectedIndex == 1)
                {
                    answerResponse();
                    repopulatequestion2();
                    txtQuestion.Text = QuestionsEasy[1];
                }
                else if (lstDisplayAnswers.SelectedIndex == 2)
                {
                    answerResponse();
                    repopulatequestion2();
                    txtQuestion.Text = QuestionsEasy[1];
                }
                else if (lstDisplayAnswers.SelectedIndex == 3)
                {
                    answerResponse();
                    repopulatequestion2();
                    txtQuestion.Text = QuestionsEasy[1];
                }



            }
            if (cboQDifficulty.SelectedIndex == 1)
            {

            }
            if (cboQDifficulty.SelectedIndex == 2)
            {

            }
        }

    }
}
    
